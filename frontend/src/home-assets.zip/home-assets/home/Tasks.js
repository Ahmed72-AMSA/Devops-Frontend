import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../task.css";
import ecomerce from "../assets2/e-commerces.jpg";
import ChooseMeals from "../assets2/charity.webp";
import DeliveryMeals from "../assets2/software.jpg";

const Tasks = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handlePrev = () => {
    setActiveIndex((prevIndex) => (prevIndex === 0 ? 1 : prevIndex - 1));
  };

  const handleNext = () => {
    setActiveIndex((prevIndex) => (prevIndex === 1 ? 0 : prevIndex + 1));
  };

  return (
    <div id='tasks'>
      <section className="py-xl-9 py-5 bg-gray-900  task">
        <div className="container con">
          <div className="row">
            <div className="col-lg-8 offset-lg-2 col-12">
              <div className="text-center mb-xl-7 mb-5">
                <small className="text-uppercase ls-md fw-semibold text-white">Your tasks</small>
                <p className="mb-0 text-white">"Believe you can and you're halfway there."</p>
              </div>
            </div>
          </div>
          <div id="carouselExampleControls" className="carousel slide pb-lg-8 pb-4 pt-1 mt-4" data-bs-ride="carousel">
            <div className="carousel-inner">
              <div className={`carousel-item ${activeIndex === 0 ? 'active' : ''}`}>
                <div className="row">
                  <div className="col-md-4">
                    <div className="card border-0 h-100 card-lift ">
                      <a href="#!"><img src={ecomerce} alt="about" className="img-fluid rounded-top-3 d-flex justify-content-center align-items-center ms-5" /></a>
                      <div className="card-body">
                        <div className="d-flex flex-column gap-2">
                          <div className="d-flex flex-column gap-4">
                             <div className=' mt-3 justify-content-center align-items-center'> 
                               <h4><span className='  text-capitalize text-warning me-1'>title:</span> making responsive front-end for this page</h4>
                               <div className=' d-flex'>
                           <h5><span className='  text-capitalize text-warning me-1'>status:</span> in progress</h5>
                           <button className='btn btn-warning ms-2'>update</button>
                           </div>

                                <form className="d-flex flex-column align-items-center">
    <div className="mb-3">
      <label htmlFor="comment" className="form-label">Write Comment</label>
      <textarea className="form-control" id="comment" rows="3"></textarea>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
                                </form>
                             </div>
                            
                            <div className="upload-file-input d-flex justify-content-center align-items-center">
                              <label htmlFor="fileInput" className="btn btn-secondary">
                                     Choose File
                                 <input type="file" id="fileInput" className="form-control" />
                              </label>
                             </div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="card border-0 h-100 card-lift">
                      <a href="#!"><img src={ChooseMeals} alt="about" className="img-fluid rounded-top-3" /></a>
                      <div className="card-body">
                        <div className="d-flex flex-column gap-2">
                          <div className="d-flex flex-column gap-4">
                          <h4><span className='  text-capitalize '>title:</span> making back-end  for this page</h4>
                          <div className=' d-flex'>
                           <h5><span className='  text-capitalize text-warning me-1'>status:</span> in progress</h5>
                           <button className='btn btn-warning ms-2'>update</button>
                           </div>

                                <form className="d-flex flex-column align-items-center">
    <div className="mb-3">
      <label htmlFor="comment" className="form-label">Write Comment</label>
      <textarea className="form-control" id="comment" rows="3"></textarea>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
                                </form>
                            <div className="upload-file-input d-flex justify-content-center align-items-center">
  <label htmlFor="fileInput" className="btn btn-secondary">
    Choose File
    <input type="file" id="fileInput" className="form-control" />
  </label>
</div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="card border-0 h-100 card-lift">
                      <a href="#!"><img src={DeliveryMeals} alt="about" className="img-fluid rounded-top-3" /></a>
                      <div className="card-body">
                        <div className="d-flex flex-column gap-2">
                          <div className="d-flex flex-column gap-4">
                          <h4><span className='  text-capitalize '>title:</span> making dashboard for this webpage</h4>
                          <div className=' d-flex'>
                           <h5><span className='  text-capitalize text-warning me-1'>status:</span> in progress</h5>
                           <button className='btn btn-warning ms-2'>update</button>
                           </div>

                                <form className="d-flex flex-column align-items-center">
    <div className="mb-3">
      <label htmlFor="comment" className="form-label">Write Comment</label>
      <textarea className="form-control" id="comment" rows="3"></textarea>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
                                </form>
                            <div className="upload-file-input d-flex justify-content-center align-items-center">
  <label htmlFor="fileInput" className="btn btn-secondary">
    Choose File
    <input type="file" id="fileInput" className="form-control" />
  </label>
</div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* Add more carousel items here */}
                </div>
              </div>
              <div className={`carousel-item ${activeIndex === 1 ? 'active' : ''}`}>
                <div className="row">
                <div className="col-md-4">
                    <div className="card border-0 h-100 card-lift">
                      <a href="#!"><img src={ecomerce} alt="about" className="img-fluid rounded-top-3 d-flex justify-content-center align-items-center" /></a>
                      <div className="card-body">
                        <div className="d-flex flex-column gap-2">
                          <div className="d-flex flex-column gap-4">
                          <h4><span className='  text-capitalize '>title:</span> making responsive front-end for this page</h4>
                          <form>
                           <div className=' d-flex'>
                           <h5><span className='  text-capitalize text-warning me-1'>status:</span> in progress</h5>
                           <button className='btn btn-warning ms-2'>update</button>
                           </div>

                          </form>
                         
                                <form className="d-flex flex-column align-items-center">
                                        <div className="mb-3">
                                            <label htmlFor="comment" className="form-label">Write Comment</label>
                                            <textarea className="form-control" id="comment" rows="3"></textarea>
                                          </div>
                                           <button type="submit" className="btn btn-primary">Submit</button>
                                </form>
                            <div className="upload-file-input d-flex justify-content-center align-items-center">
  <label htmlFor="fileInput" className="btn btn-secondary">
    Choose File
    <input type="file" id="fileInput" className="form-control" />
  </label>
</div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="card border-0 h-100 card-lift">
                      <a href="#!"><img src={ChooseMeals} alt="about" className="img-fluid rounded-top-3" /></a>
                      <div className="card-body">
                        <div className="d-flex flex-column gap-2">
                          <div className="d-flex flex-column gap-4">
                          <h4><span className='  text-capitalize '>title:</span> making back-end  for this page</h4>
                          <div className=' d-flex'>
                           <h5><span className='  text-capitalize text-warning me-1'>status:</span> in progress</h5>
                           <button className='btn btn-warning ms-2'>update</button>
                           </div>

                                <form className="d-flex flex-column align-items-center">
    <div className="mb-3">
      <label htmlFor="comment" className="form-label">Write Comment</label>
      <textarea className="form-control" id="comment" rows="3"></textarea>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
                                </form>
                            <div className="upload-file-input d-flex justify-content-center align-items-center">
  <label htmlFor="fileInput" className="btn btn-secondary">
    Choose File
    <input type="file" id="fileInput" className="form-control" />
  </label>
</div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                 
                  {/* Add more carousel items here */}
                </div>
              </div>
            
            </div>
            <button className="carousel-control-prev m-0" type="button" onClick={handlePrev}>
              <span className="carousel-control-prev-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" onClick={handleNext}>
              <span className="carousel-control-next-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
          <div className="row">
            <div className="col-12 d-flex justify-content-center p-3">
              <button className="btn btn-prev btn-icon btn-white rounded-pill me-3 text-black bg-warning">
                <i className="bi bi-arrow-left-short fs-3 lh-1"></i>
              </button>
              <button className="btn btn-next btn-icon btn-white rounded-pill text-white bg-warning" >
                <i className="bi bi-arrow-right-short fs-3 lh-1"></i>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Tasks;
