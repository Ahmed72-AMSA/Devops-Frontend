import React from "react";

import ecomerce from "../assets2/e-commerces.jpg";
import ChooseMeals from "../assets2/charity.webp";
import DeliveryMeals from "../assets2/software.jpg";
import 'bootstrap/dist/css/bootstrap.min.css';

import "../projects.css";

const Otasks = () => {
  return (
    <div className="work-section-wrapper " id="Otasks">
    <div className="work-section-top">
     
      <h1 className="primary-heading">Other's tasks</h1>
      <p className="primary-text">
      "The only way to do great work is to love what you do." 
      </p>
    </div>
    <div className="work-section-bottom">
      <div className="grid-container">
        
          <div className="grid-item" key="e-commerce organization">
            <div className="info-boxes-img-container">
              <img src={ecomerce} alt="" />
            </div>
            <h2>e-commerce organization</h2>
            <p>making e-commerce website for handling customers orders</p>
            <p><span className='  text-capitalize text-warning me-1'>Status:</span> In Progress</p>
            <h5> <span className='  text-capitalize text-warning me-1'>developer Name:</span>ahmed sayed</h5>
 
          </div>
          <div className="grid-item" key="charity organization">
            <div className="info-boxes-img-container">
              <img src={ChooseMeals} alt="" />
            </div>
            <h2>charity organization</h2>
            <p>making charity website for handling events,campaigns and donations</p>
            <p><span className='  text-capitalize text-warning me-1'>Status:</span> Started</p>
            <h5> <span className='  text-capitalize text-warning me-1'>developer Name:</span>abdelrhman sayed</h5>
    
          </div>
          <div className="grid-item" key="software orders">
            <div className="info-boxes-img-container">
              <img src={DeliveryMeals} alt="" />
            </div>
            <h2>software orders</h2>
            <p>building software projects in agile method</p>
            <p><span className='  text-capitalize text-warning me-1'>Status:</span> Done</p>
   
            <h5> <span className='  text-capitalize text-warning me-1'>developer Name:</span>Atress Ahmed</h5>
          </div>
       
      
      </div>
    </div>
  </div>

  );
};

export default Otasks;
