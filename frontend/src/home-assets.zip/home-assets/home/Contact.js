import React from "react";

const Contact = () => {
  return (
    <div className="contact-page-wrapper" id="Contact">
      <h1 className="primary-heading">Have Question In Mind?</h1>
      <h5 className="primary-text">feel free to massege your leader</h5>
      <div className="contact-form-container">
        <input type="text" placeholder="ahmed_sayed@gmail.com" className="form-control"/>
        <button className="secondary-button ms-2">Submit</button>
      </div>
    </div>
  );
};

export default Contact;
